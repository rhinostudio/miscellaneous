<?php
if(!isset($_POST['intern'])){
    echo -1;
}

require_once(__DIR__.'/common/parameterhelper.class.php');
$paramHelper = new ParameterHelper();
if(isset($_POST['Name']) && !empty($_POST['Name'])){
    $paramHelper->addName($_POST['Name']);
}
if(isset($_POST['Genre']) && !empty($_POST['Genre'])){
    $paramHelper->addGenre($_POST['Genre']);
}
if(isset($_POST['RuntimeMax']) && !empty($_POST['RuntimeMax']) && isset($_POST['RuntimeMin']) && !empty($_POST['RuntimeMin'])){
    $paramHelper->addRuntime($_POST['RuntimeMax'], $_POST['RuntimeMin']);
}elseif(isset($_POST['RuntimeMax']) && !empty($_POST['RuntimeMax'])){
    $paramHelper->addRuntime($_POST['RuntimeMax']);
}
$paramJson = $paramHelper->getParameterJson();

require_once(__DIR__.'/common/requesthelper.class.php');
$apiPath = '104.131.117.47/devel/api/api.php';
$request = new RequestHelper($apiPath, $paramJson);
$response = $request->sendRequest();

//test moviesource
$fh = fopen('./logs.txt', 'a+');
fwrite($fh, 'movies: '."\r\n");
fwrite($fh, var_export($response, true)."\r\n");
fwrite($fh, 'end movie'."\r\n\r\n");
//end moviesource
echo $response;
