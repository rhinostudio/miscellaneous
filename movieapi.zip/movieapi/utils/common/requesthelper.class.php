<?php
class RequestHelper{
    private $_url = '';
    private $_jsondata = '';
    private $_response = '';
    
    public function __construct($url='', $data='') {
        $this->_url = $url;
        $this->_jsondata = $data;
    }
    
    public function setUrl($url){
        $this->_url = $url;
    }
    
    public function setData($data){
        $this->_jsondata = $data;
    }
    
    public function sendRequest($url=''){
        if(!empty($url)){
            $this->_url = $url;
        }
        $ch = curl_init();
        if($ch === false){
            echo -1;
            exit();
        }
        $optionarr = array(
            CURLOPT_FOLLOWLOCATION => TRUE,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_URL => $this->_url,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $this->_jsondata,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Content-Length: '.  strlen($this->_jsondata)
            ),
            CURLOPT_HEADER => FALSE
        );
        curl_setopt_array($ch, $optionarr);
        $this->_response = curl_exec($ch);
        curl_close($ch);
        if($this->_response === false){
            $this->_response = -1;
        }
        $this->_trimResponse();
        return $this->_response;
    }
    
    public function getResponse(){
        return $this->_response;
    }
    
    private function _trimResponse(){
        if(!empty($this->_response)){
            $startPos = strpos($this->_response, '<body>');
            $endPos = strrpos($this->_response, '</body>');
            $this->_response = substr($this->_response, $startPos+6, $endPos-$startPos-6);
        }
    }
}