<?php
class ParameterHelper{
    private $_paramJsonArray = array('Request' => array());
    
    public function addName($names){
        $nameArr = explode(',', $names);
        foreach($nameArr as $name){
            $this->_paramJsonArray['Request'][] = array('Field'=>'Name', 'Value'=>$name);
        }
    }
    
    public function addGenre($value){
        $this->_paramJsonArray['Request'][] = array('Field'=>'Genre', 'Value'=>  explode(',', $value));
    }
    
    public function addRuntime($max, $min=0){
        $this->_paramJsonArray['Request'][] = array('Field'=>'Runtime', 'Value'=>array('Min'=>$min, 'Max'=>$max));
    }
    
    public function getParameterJson(){
        return json_encode($this->_paramJsonArray);
    }
}