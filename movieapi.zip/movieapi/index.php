<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>Movie Search</title>
        <link type="text/css" rel="stylesheet" href="./css/index.css">
        <script type="text/javascript" src="./js/jquery.3.0.js"></script>
        <script type="text/javascript" src="./js/index.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="nav">
                <div class="search-header">
                    Choose Search Condition:
                </div>
                <div class="search-body">
                    <div class="search-conditon-section">
                        <label for="search_name">Name: </label>
                        <input type="text" id="search_name">
                        &ensp;&ensp;&ensp;enable option*
                        <input type="checkbox" id="search_name_enabled" value="1">
                    </div>
                    <div class="search-conditon-section">
                        <label for="search_genre">Genre: </label>
                        <select id="search_genre" multiple="true">
                            <option value="Comedy">Comedy</option>
                            <option value="Space">Space</option>
                            <option value="Drama">Drama</option>
                            <option value="Romance">Romance</option>
                            <option value="Psychology">Psychology</option>
                        </select>
                        &ensp;&ensp;&ensp;enable option*
                        <input type="checkbox" id="search_genre_enabled" value="1">
                    </div>
                    <div class="search-conditon-section">
                        <label for="search_runtime_range_min">Runtime Range: </label>
                        (Min)<input type="text" id="search_runtime_range_min" placeholder="Min(optional)">
                        &ensp;&ensp;
                        (Max)<input type="text" id="search_runtime_range_max" placeholder="Max">
                        &ensp;&ensp;&ensp;enable option*
                        <input type="checkbox" id="search_runtime_range_enabled" value="1">
                    </div>
                    <div class="search-conditon-section">
                        <input type="button" id="search_btn" value="Search" eclk="0">
                    </div>
                </div>
            </div>
            <div class="main">
                <div id="movies"></div>
            </div>
        </div>
    </body>
</html>
