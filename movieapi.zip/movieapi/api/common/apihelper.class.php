<?php
class ApiHelper{
    private $_searchConditionArr = array();
    private $_dataFilePath = '';
    private $_movieSourceArr = array();
    private $_movieArr = array('Response'=>array());
    
    public function __construct($searchconditionjson='', $datafile=''){
        //allow for cors
        header('Access-Controll-Allow-Origin: *');
        header('Access-Controll-Allow-Methods: *');
        header('Content-Type: application/json');
        if(!empty($searchconditionjson)){
            $this->_searchConditionArr = json_decode($searchconditionjson, true);
        }
        if(!empty($datafile)){
            $this->_dataFilePath = $datafile;
            $this->_movieSourceArr = json_decode(file_get_contents($this->_dataFilePath), true);
        }
    }
    
    public function setSearchConditionJson($searchconditionjson){
        if(!empty($searchconditionjson)){
            $this->_searchConditionArr = json_decode($searchconditionjson, true);
        }
    }
    
    public function setDataFilePath($datafile){
        if(!empty($datafile)){
            $this->_dataFilePath = $datafile;
            $this->_movieSourceArr = json_decode(file_get_contents($this->_dataFilePath), true);
        }
    }
    
    public function getMovieJson(){
        return json_encode($this->_movieArr);
    }
    
    public function getSearchConditionArr(){
        return $this->_searchConditionArr;
    }
    
    public function getMovieSourceArr(){
        return $this->_movieSourceArr;
    }
    
    public function searchMovie(){
        if(!empty($this->_searchConditionArr['Request']) && count($this->_searchConditionArr['Request']) > 0){
            foreach($this->_searchConditionArr['Request'] as $search){
                switch($search['Field']){
                    case 'Name':
                        $this->_fetchMovieByName($search['Value'], $this->_movieArr['Response']);
                        break;
                    case 'Genre':
                        $this->_fetchMovieByGenre($search['Value'], $this->_movieArr['Response']);
                        break;
                    case 'Runtime':
                        $this->_fetchMovieByRuntime($search['Value'], $this->_movieArr['Response']);
                        break;
                }
            }
        }
        
        return json_encode($this->_movieArr);
    }
    
    private function _fetchMovieByName($name, &$movieArr){
        foreach($this->_movieSourceArr['Movies'] as $movie){
            if(strpos($movie['Name'], $name) !== false){
                $movieArr[] = $movie;
            }
        }
    }
    
    private function _fetchMovieByGenre($genreArr, &$movieArr){
        foreach($this->_movieSourceArr['Movies'] as $movie){
            $intersect = array_intersect($genreArr, $movie['Genre']);
            if(!empty($intersect) && count($intersect) > 0){
                $movieArr[] = $movie;
            }
        }
    }
    
    private function _fetchMovieByRuntime($runtime, &$movieArr){
        foreach($this->_movieSourceArr['Movies'] as $movie){
            if($runtime['Max'] >= $movie['Runtime']){
                if(isset($runtime['Min'])){
                    if($runtime['Min'] <= $movie['Runtime']){
                        $movieArr[] = $movie;
                    }
                }else{
                    $movieArr[] = $movie;
                }
            }
        }
    }
    
}