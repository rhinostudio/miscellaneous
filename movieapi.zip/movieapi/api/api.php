<?php
$jsonData = file_get_contents('php://input');
//import ApiHelper class
require_once(__DIR__.'/common/apihelper.class.php');
$apiHelper = new ApiHelper($jsonData, __DIR__.'/data/movies.json');
$apiHelper->searchMovie();
echo $apiHelper->getMovieJson();