$(function(){
    // api test
    $('#search_btn').click(function(){
        var me = this;
        if(+$(me).attr('eclk') === 1){
            return false;
        }
        $(me).attr('eclk', 1);
        var _data = getParams(), _url = './utils/ajaxsearch.php';
        if(+_data.errno === 1){
            return false;
        }
        console.log('posted data: ', _data);
        $.ajax({
            url: _url,
            type: 'post',
            data: _data,
            //dataType: 'json',
            context: me,
            success: function(data, status, xhr){
                console.log('Returned: ', data, '; Status: ', xhr.status);
                if(+data == 1){
                    $('#movies').html('Internal Error, please contact us..');
                    return;
                }
                $('#movies').html(data);
            },
            error: function(xhr, status, errMsg){
                console.log('Error: ', errMsg);
            },
            complete: function(){
                $(this).attr('eclk', 0);
            }
        });
    });
});

function getParams(){
    var params = {};
    params.intern = 1;
    if($('#search_name_enabled').prop('checked')){
        var _name = $('#search_name').val();
        if($.trim(_name)){
            params.Name = $.trim(_name);
        }else{
            params.errno = 1;
            alert('Name can not be empty when enabled');
        }
    }
    if($('#search_genre_enabled').prop('checked')){
        var _genre = $('#search_genre').val();
        if($.trim(_genre)){
            params.Genre = $.trim(_genre);
        }else{
            params.errno = 1;
            alert('Genre can not be empty when enabled');
        }
    }
    if($('#search_runtime_range_enabled').prop('checked')){
        var _runtimeMin = $('#search_runtime_range_min').val();
        if($.trim(_runtimeMin)){
            params.RuntimeMin = $.trim(_runtimeMin);
        }
        var _runtimeMax = $('#search_runtime_range_max').val();
        if($.trim(_runtimeMax)){
            params.RuntimeMax = $.trim(_runtimeMax);
        }else{
            params.errno = 1;
            alert('Max can not be empty when enabled');
        }
    }
    return params;
}