<?php

/**
 * Description of syllabusutility
 *
 * @author Tim
 */
class SyllabusUtility {
    private $_dbmanager;
    
    public function __construct($dbmanager){
        $this->_dbmanager = $dbmanager;
    }
    
    public function getTopicById($type, $syllabusid, $sectionid, $topicid, $subtopicid){
        $topicInfo = array('topicname'=>'', 'subtopicname'=>'');
        switch($type){
            case 'tid':
                $sql = "SELECT 
                                    TBL_MS.SectionID, 
                                    TBL_SS.SectionName, 
                                    TBL_MS.SectionSeq, 
                                    TBL_MT.TopicID, 
                                    TBL_ST.TopicName, 
                                    TBL_MT.TopicSeq, 
                                    TBL_MST.SubTopicID, 
                                    TBL_SST.SubTopicName, 
                                    TBL_MST.SubTopicSeq,
                                    TBL_MST.CTopicID,
                                    TBL_SST.Objectives
                            FROM 
                                    TBL_ModuleSections TBL_MS, 
                                    TBL_ModuleTopics TBL_MT, 
                                    TBL_ModuleSubTopics TBL_MST, 
                                    TBL_SyllabusSections TBL_SS, 
                                    TBL_SyllabusTopics TBL_ST, 
                                    TBL_SyllabusSubTopics TBL_SST 
                            WHERE 
                                    TBL_SS.SubjectID='MATH' AND 
                                    TBL_SS.SectionID=TBL_MS.SectionID AND 
                                    TBL_MS.SyllabusID='".$syllabusid."' AND 
                                    TBL_ST.SubjectID='MATH' AND 
                                    TBL_ST.SectionID=TBL_MT.SectionID AND 
                                    TBL_ST.TopicID=TBL_MT.TopicID AND 
                                    TBL_MT.SyllabusID='".$syllabusid."' AND 
                                    TBL_SST.SubjectID='MATH' AND 
                                    TBL_SST.SectionID=TBL_MST.SectionID AND 
                                    TBL_SST.TopicID=TBL_MST.TopicID AND 
                                    TBL_SST.SubTopicID=TBL_MST.SubTopicID AND 
                                    TBL_MST.SyllabusID='".$syllabusid."' AND 
                                    TBL_MT.SectionID=TBL_MS.SectionID AND 
                                    TBL_MST.SectionID=TBL_MT.SectionID AND 
                                    TBL_MST.TopicID=TBL_MT.TopicID AND
                                    TBL_SST.SectionID='".$sectionid."' AND 
                                    TBL_SST.TopicID='".$topicid."' AND 
                                    TBL_SST.SubTopicID='".$subtopicid."'  
                            ORDER BY 
                                    TBL_MS.SectionSeq, 
                                    TBL_MT.TopicSeq, 
                                    TBL_MST.SubTopicSeq";
                break;
            case 'atid':
                $sql = "SELECT 
                                tb1.CTopicID, 
                                tb1.CTopicName, 
                                tb1.ChapterID, 
                                tb1.SectionID, 
                                tb1.TopicID, 
                                tb1.SubTopicID, 
                                tb1.ContentType, 
                                tb1.ContentID, 
                                tb1.OrderID,
                                tb2.Objectives
                                tb2.SubTopicName 
                        FROM 
                                QRY_".$_SESSION['SessionSchoolID']."_SyllabusACETopic tb1 
                                LEFT JOIN TBL_SyllabusSubTopics tb2 
                                        ON (tb1.SectionID=tb2.SectionID AND tb1.TopicID=tb2.TopicID AND tb1.SubTopicID=tb2.SubTopicID AND tb1.SubjectID='MATH'  AND tb1.SubjectID=tb2.SubjectID) ,
                                QRY_CHHS_SyllabusChapter tb3
                        WHERE 
                                tb1.SyllabusID='".$syllabusid."' AND 
                                tb1.ChapterID=tb3.ChapterID AND
                                tb2.SectionID='".$sectionid."' AND
                                tb2.TopicID='".$topicid."' AND
                                tb2.SubTopicID='".$subtopicid."'
                        ORDER BY 
                                tb1.OrderID";
                break;
            case 'ttid':
                $sql = "SELECT 
                                tb1.CTopicID, 
                                tb1.CTopicName, 
                                tb1.ChapterID, 
                                tb1.SectionID, 
                                tb1.TopicID, 
                                tb1.SubTopicID, 
                                tb1.ContentType, 
                                tb1.ContentID, 
                                tb1.OrderID,
                                tb2.Objectives,
                                tb2.SubTopicName 
                        FROM 
                                QRY_".$_SESSION['SessionSchoolID']."_SyllabusTopic tb1 
                                LEFT JOIN TBL_SyllabusSubTopics tb2 
                                        ON (tb1.SectionID=tb2.SectionID AND tb1.TopicID=tb2.TopicID AND tb1.SubTopicID=tb2.SubTopicID AND tb1.SubjectID='MATH'  AND tb1.SubjectID=tb2.SubjectID) ,
                                QRY_CHHS_SyllabusChapter tb3
                        WHERE 
                                tb1.SyllabusID='".$syllabusid."' AND 
                                tb1.ChapterID=tb3.ChapterID AND
                                tb2.SectionID='".$sectionid."' AND
                                tb2.TopicID='".$topicid."' AND
                                tb2.SubTopicID='".$subtopicid."'
                        ORDER BY 
                                tb1.OrderID";
                break;
        }
        if(isset($sql)){
            $result = $this->_dbmanager->execute($sql);
            if($result){
                $row = $this->_dbmanager->fetch_array($result);
                if($type == 'tid'){
                    $topicInfo['topicname'] = $row['TopicName'];
                    $topicInfo['subtopicname'] = $row['SubTopicName'];
                }else{
                    $topicInfo['topicname'] = $row['CTopicName'];
                    $topicInfo['subtopicname'] = $row['SubTopicName'];
                }
            }
        }
        return $topicInfo;
    }
    
    
}

?>