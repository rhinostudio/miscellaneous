<?php
/**
 * Description of DbManager
 *
 * @author Tim
 */
require_once(__DIR__.'/dbmanager.class.php');
require_once(__DIR__.'/timemanager.class.php');

class LearningPackage {
    private $_dbmanager;
    private $_timemanager;
    private $_errno;
    private $_assignid;
    private $_assigner;
    private $_startdate;
    private $_enddate;
    private $_lockall;
    private $_id;
    private $_creator;
    private $_date;
    private $_title;
    private $_description;
    private $_courseid;
    private $_activities;
    private $_studentid;
    
    private $_mode; // 0:default; 1:learning-package view; 2: assignment view
    
    public function __construct() {
        $this->_errno = 0;
        $this->_dbmanager = DbManager::getInstance();
        if(!$this->_dbmanager->connect2Db()){
            $this->_errno = 1;
            return ;
        }
        $this->_timemanager = new TimeManager();
        $this->_id = 0;
        $this->_creator = '';
        $this->_date = '0000-00-00 00:00:00';
        $this->_title = '';
        $this->_description = '';
        $this->_courseid = '';
        $this->_activities = array();
        $this->_assignid = 0;
        $this->_assigner = '';
        $this->_startdate = '0000-00-00 00:00:00';
        $this->_enddate = '0000-00-00 00:00:00';
        $this->_lockall = 0;
        $this->_mode = 0;
        $this->_studentid = $_SESSION['SessionUserID'];
    }
    
    /*
     * public functions which can be called outside
     */
    public function setStudentId($studentid) {
        $this->_studentid = $studentid;
    }
    public function create(array $learningpackageentity_assignmententity, $mode) {
        // $mode: 1, learningpackage; 2, assignment; 3, learningpackage and assignment
        $learningpackageid = 0;
        
        return $learningpackageid;
    }
    
    public function read($learningpackageid_assignmentid, $mode) {  // $mode: 1, learningpackage; 2, assignment
        $this->_mode = $mode;
        if($mode == 1){ // 1: learning-package view
            $this->_id = $learningpackageid_assignmentid;
        }else{  // 2: assignment view
            $this->_assignid = $learningpackageid_assignmentid;
        }
        $this->_read($mode);
    }
    
    public function update(array $learningpackageentity_assignmententity, $mode) {
        ;
    }
    
    public function delete($learningpackageid_assignmentid, $mode) {
        ;
    }
    
    public function getLock(){
        return $this->_lockall;
    }
    
    public function getInfo(){
        return array(
            'id' => $this->_id,
            'creator' => $this->_creator,
            'date' => $this->_date,
            'title' => $this->_title,
            'description' => $this->_description,
            'courseid' => $this->_courseid,
            'assignid' => $this->_assignid,
            'assigner' => $this->_assigner,
            'startdate' => $this->_startdate,
            'enddate' => $this->_enddate,
            'lock' => $this->_lockall
        );
    }
    
    public function getActitivies(){
        return $this->_activities;
    }
    
    public function setActivitiesLock($index, $lock){
        $this->_activities[$index]['lock'] = $lock;
    }
    
    public function listHtml(){
        return $this->_listHtml();
    }
    

    /*
     * internal functions
     */
    private function _read($mode){
        if($mode == 1){
            $sql_lp = "select concat(U.FirstName, ' ', U.LastName) as Creator, LP.Date, LP.Title, LP.Description, LP.CourseID
                        from QRY_".$_SESSION['SessionSchoolID']."_LearningPackage LP, TBL_Users U
                        where LP.LPID = ".$this->_id." and LP.UserID = U.UserID";
            $result_lp = $this->_dbmanager->execute($sql_lp);
            if($result_lp){
                $row_lp = $this->_dbmanager->fetch_array($result_lp);
                $this->_creator = $row_lp['Creator'];
                $this->_date = $row_lp['Date'];
                $this->_title = $row_lp['Title'];
                $this->_description = $row_lp['Desciption'];
                $this->_courseid = $row_lp['CourseID'];
            }
        }else{  // assignment
            $sql_lp = "select concat(U.FirstName, ' ', U.LastName) as Assigner, ASS.StartDate, ASS.EndDate, ASS.LockAll, LP.LPID, LP.Date, LP.Title, LP.Description, LP.CourseID
                        from QRY_".$_SESSION['SessionSchoolID']."_LearningPackage_Assignment ASS, QRY_".$_SESSION['SessionSchoolID']."_LearningPackage LP, TBL_Users U
                        where ASS.LPAssignID = ".$this->_assignid." and ASS.LPID = LP.LPID and ASS.UserID = U.UserID";
            $result_lp = $this->_dbmanager->execute($sql_lp);
            if($result_lp){
                $row_lp = $this->_dbmanager->fetch_array($result_lp);
                $this->_assigner = $row_lp['Assigner'];
                $this->_startdate = $row_lp['StartDate'];
                $this->_enddate = $row_lp['EndDate'];
                $this->_lockall = $row_lp['LockAll'];
                $this->_id = $row_lp['LPID'];
                $this->_date = $row_lp['Date'];
                $this->_title = $row_lp['Title'];
                $this->_description = $row_lp['Description'];
                $this->_courseid = $row_lp['CourseID'];
            }
        }

        $sql_activities = "select ACT.LPActivityID, ACT.ActivityTypeID, ACT.Title, ACT.Description, ACT.ContentID
                           from QRY_".$_SESSION['SessionSchoolID']."_LearningPackage_Activities ACT
                           where ACT.LPID = ".$this->_id."
                           order by ACT.OrderID";
        $result_activities = $this->_dbmanager->execute($sql_activities);
        if($result_activities){
            while($row_activities = $this->_dbmanager->fetch_array($result_activities)){
                $this->_activities[] = array(
                    'studentid' => $this->_studentid,
                    'mode' => $mode,
                    'lpasignid' => $this->_assignid,
                    'lpid' => $this->_id,
                    'id' => $row_activities['LPActivityID'],
                    'typeid' => $row_activities['ActivityTypeID'],
                    'title' => $row_activities['Title'],
                    'description' => $row_activities['Description'],
                    'contentid' => $row_activities['ContentID'],
                    'lock' => $this->_lockall
                );
            }
        }
    }
    
    private function _listHtml(){
        $html = '';
        switch($this->_mode){
            case 1:
                $locksActivities = '';
                foreach($this->_activities as $activity){
                    $locksActivities .= $activity['lock'].'-';
                }
                $locks = substr($locksActivities, 0, -1);
                $html .= '<div id="quesheader">';
                if($this->_studentid == $_SESSION['SessionUserID']){
                    $html .= '<a href="/w/admin/lpb" class="pull-right back-btn">Back</a>';
                }
                $html .=       '<span id="header-icon">
                                <img class="shimgmrgn" src="/w/img/icons/sec-lpb-icon.png">
                            </span>
                            <span class="me-title">'.$this->_title.'</span>
                            <input type="hidden" id="lp_lock" value="'.$this->_lockall.'" data="'.$locks.'" />
                        </div>

                        <div id="quescontent-holder">
                            <div id="quescontent">';
                break;
            case 2:
                $locksActivities = '';
                foreach($this->_activities as $activity){
                    $locksActivities .= $activity['lock'].'-';
                }
                $locks = substr($locksActivities, 0, -1);
                $html .=   '<div class="page-header">
                                <div class="clearfix content-heading">';
                if($this->_studentid == $_SESSION['SessionUserID']){
                    $html .= '<a href="javascript:void(0);" class="pull-right back-btn white-btn" data="'.$this->_encodeUrl().'">Back</a>';
                }
                $html .=           '<img id="title-icon" class="pull-left" src="/w/img/icons/sec-lpb-icon.png">
                                    <h3>'.$this->_title.($this->_studentid == $_SESSION['SessionUserID'] ? '' : (' ('.$this->_retrieveStudentById($this->_studentid).')')).'</h3>
                                    <input type="hidden" id="lp_lock" value="'.$this->_lockall.'" data="'.$locks.'" />    
                                </div>
                            </div>
                            <div class="row" style="margin-bottom:10px;">
                                <div class="col-sm-4 left-column-padding">
                                    <div class="info-container">
                                        <div class="date-holder start-date-container">				
                                            <p>Start Date</p>				
                                            <p class="info-text-2">'.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $this->_startdate, 1).'</p>				
                                            <p class="info-text-1">'.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $this->_startdate, 10).'</p>			
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 middle-column-padding">
                                    <div class="info-container">
                                        <div class="date-holder end-date-container">
                                            <p>End Date</p>
                                            <p class="info-text-2">'.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $this->_enddate, 1).'</p>
                                            <p class="info-text-1">'.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $this->_enddate, 10).'</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 right-column-padding">
                                    <div class="info-container">
                                        <div class="info-holder">				
                                            <p>Assigned by</p>
                                            <p class="info-text-2">'.$this->_assigner.'</p>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                break;
        }
        
        return $html;
    }
    
    private function _dateFormat($mysql_datetime, $mode){   // $mode 0:datettime, 1:date, 2:time
        $dateTime = array();
        if(empty($mysql_datetime)){
            return '-';
        }
        if(preg_match('/(\d+)-(\d+)-(\d+)\s+(\d+):(\d+):(\d+)/', $mysql_datetime, $dateTime) == 1){
            $pattern = '';
            switch($mode){
                case 0:
                    $pattern = 'd M y, h:i A';
                    break;
                case 1:
                    $pattern = 'd M y';
                    break;
                case 2:
                    $pattern = 'h:i A';
                    break;
            }
            return date($pattern, mktime($dateTime[4], $dateTime[5], $dateTime[6], $dateTime[2], $dateTime[3], $dateTime[1]));
        }else{
            return 'format-error';
        }
    }
    
    private function _retrieveStudentById($studentid){
        $retValue = '';
        $sql = "select concat(U.FirstName, ' ', U.LastName) as Name from TBL_Users U where UserID = ".$studentid;
        $result = $this->_dbmanager->execute($sql);
        if($result){
            $row = $this->_dbmanager->fetch_array($result);
            $retValue = trim($row['Name']);
        }
        return $retValue;
    }
    
    // encrypt url for quiz, worksheet, journal
    private function _encodeUrl(){   //$activitytype: defined and used in /w/assignments/view.php
        $random = substr(time()* (600*60*60), 0, 6);
        $random2 = substr(time() * (300*60*60), 0, 6);
        return $random.$this->_courseid.$random2."10_1";
    }
}
?>