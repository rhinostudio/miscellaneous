<?php

/**
 * Description of itemlesson
 *
 * @author Tim
 */
require_once(__DIR__.'/item.class.php');

class ItemLink extends Item {
    private $_entityTable;
    private $_assignmentTable;
    private $_traceTable;
    
    public function __construct() {
        parent::__construct();
        $this->_entityTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_Links';
        $this->_assignmentTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_LinksAssignment';
        $this->_traceTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_UsageFL';
    }
    
    /*
     * Override functions
     */
    public function updateViews($activityid, $id, $lpassignid) {
        $retValue = 0;
        $url = '';
        $courseid = '';
        $syllabusid = 0;
        $sectionid = 0;
        $topicid = 0;
        $subtopicid = 0;
        $assignid = 0;
        $sql_link = "select L.URL, L.CourseID, L.SyllabusID, L.SectionID, L.TopicID, L.SubTopicID, LA.AssignID from ".$this->_entityTable." L, ".$this->_assignmentTable." LA where LA.ID = L.ID and LA.LPAssignID = ".$lpassignid." and LA.LPActivityID = ".$activityid." and LA.ID = ".$id."";
        
        $fh = fopen("item-link.txt", 'a+');
        if($fh){
                fwrite($fh, "itemlink.class.php\r\n");
                fwrite($fh, $sql_link."\r\n\r\n");
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $result_link = $this->_dbmanager->execute($sql_link);
        if($result_link && $this->_dbmanager->num_rows($result_link) > 0){
            $row_link = $this->_dbmanager->fetch_array($result_link);
            $url = $row_link['URL'];
            $courseid = $row_link['CourseID'];
            $syllabusid = $row_link['SyllabusID'];
            $sectionid = $row_link['SectionID'];
            $topicid = $row_link['TopicID'];
            $subtopicid = $row_link['SubTopicID'];
            $assignid = $row_link['AssignID'];
        }
        
        $sql = "insert into ".$this->_traceTable."(UserID, UserTypeID, CourseID, SyllabusID, SectionID, TopicID, SubTopicID, ID, StartDate, IPAddress, AssignID) values (".$_SESSION['SessionUserID'].", ".$_SESSION['SessionUserTypeID'].", '"
                .$courseid."', '".$syllabusid."', '".$sectionid."', '".$topicid."', '".$subtopicid."', '".$id."', now(), '".$_SERVER['HTTP_PC_REMOTE_ADDR']."', ".$assignid.")";
        
        $fh = fopen("item-link.txt", 'a+');
        if($fh){
                fwrite($fh, "itemlink.class.php\r\n");
                fwrite($fh, $sql."\r\n\r\n");
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $this->_dbmanager->execute($sql);
        if($this->_dbmanager->affected_rows() > 0){
            $retValue = '0^'.$url;
        }else{
            $retValue = 1;
        }
        return $retValue;
    }
    
}

?>