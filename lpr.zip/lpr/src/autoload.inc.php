<?php
function __autoload($classname){
    $filePath = __DIR__.'/'.strtolower($classname).'.class.php';
    if(file_exists($filePath)){
        require_once($filePath);
    }else{
        $handler = fopen(__DIR__.'/../log/error.log', 'a+');
        if($handler){
            fwrite($handler, '[File required]'.$filePath.' does not exist.');
        }
        fclose($handler);
    }
}
?>
