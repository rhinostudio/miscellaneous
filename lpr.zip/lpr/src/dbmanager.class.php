<?php
/**
 * Description of DbManager
 *
 * @author Tim
 */
require_once('/var/www/w/config/mysql_secret.php');
class DbManager {
    private $_server = DB_HOST;
    private $_db = DB_NAME;
    private $_user = DB_USER;
    private $_passwd = DB_PASSWORD;
    
    private function __construct(){
        
    }
    
    private static $_instance = NULL;
    
    public static function getInstance(){
        if(DbManager::$_instance === NULL){
            DbManager::$_instance = new DbManager();
        }
        return DbManager::$_instance;
    }
    
    public function connect2Db(){
        $link = mysql_connect($this->_server, $this->_user, $this->_passwd);
        if($link == FALSE){
            echo 'connect db failed..';
            return false;
        }
        return mysql_select_db($this->_db);
    }
    
    public function execute($sql){
        return mysql_query($sql);
    }
    
    public function fetch_array($result){
        return mysql_fetch_array($result);
    }
    
    public function affected_rows(){
        return mysql_affected_rows();
    }
    
    public function num_rows($result){
        return mysql_num_rows($result);
    }
}
?>