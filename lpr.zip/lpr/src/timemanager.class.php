<?php

/**
 * Description of timemanager
 *
 * @author Tim
 */
class TimeManager {

    public function ShowCurrentTime($Timezone, $format) {
        if ($Timezone == "") {
            $Timezone = "Asia/Singapore";
        }
        switch ($format) {
            case 1:
                $TimeFormat = "d M y";
                break;

            case 2:
                $TimeFormat = "d M y, h:i A";
                break;

            case 3:
                $TimeFormat = "Y-m-d H:i:s";
                break;

            case 4:
                $TimeFormat = "d M Y, H:i A";
                break;

            case 5:
                $TimeFormat = "d M Y, H:i:s A";
                break;

            case 6:
                $TimeFormat = "d M y, h:i:s A";
                break;

            case 7:
                $TimeFormat = "d/m/Y";
                break;
        }

        $dateTime = new DateTime("now");
        $dateTimeZone = new DateTimeZone($Timezone);
        $dateTime->setTimezone($dateTimeZone);
        $CurrentLocalTime = $dateTime->format("$TimeFormat"); // the local country current time
        return $CurrentLocalTime;
    }

    public function ConvertToLocalTime($Timezone, $DateValue, $format) {
        /**
          $Timezone = User Session TimeZone
          $DateValue = date to be adjusted. must be in "Y-m-d H:i:s" format
          $format = output date format
          1 = "d M y";
          2 = "d M y g:i A";
          3 = "Y-m-d H:i:s";
         */
        if ($Timezone == "") {
            $Timezone = "Asia/Singapore";
        }
        switch ($format) {
            case 1:
                $TimeFormat = "d M y";
                break;

            case 2:
                $TimeFormat = "d M y, h:i A";
                break;

            case 3:
                $TimeFormat = "Y-m-d H:i:s";
                break;

            case 4:
                $TimeFormat = "d M Y, h:i A";
                break;

            case 5:
                $TimeFormat = "d M Y, h:i:s A";
                break;

            case 6:
                $TimeFormat = "d M y, h:i A";
                break;

            case 7:
                $TimeFormat = "d/m/Y";
                break;

            case 8:
                $TimeFormat = "d M y, h:i:s A";
                break;

            case 9:
                $TimeFormat = "H:i A";
                break;

            case 10:
                $TimeFormat = "h:i A";
                break;
        }
        //echo "Current User Local Time: ".ShowCurrentTime($Timezone);
        $dateTime = new DateTime($DateValue);
        $dateTimeZone = new DateTimeZone($Timezone);
        $dateTime->setTimezone($dateTimeZone);
        $LocalTime = $dateTime->format($TimeFormat); // converted current time
        /*
          $LocalTime = date($TimeFormat, strtotime($DateValue)+GetLocalToServerOffset($Timezone))
         */
        return $LocalTime;
    }

    public function ConvertToServerTime($Timezone, $DateValue, $format) {
        /**
          $Timezone = User Session TimeZone
          $DateValue = date to be adjusted. must be in "Y-m-d H:i:s" format
          $format = output date format
          1 = "d M y";
          2 = "d M y g:i A";
          3 = "Y-m-d H:i:s";
         */
        if ($Timezone == "") {
            $Timezone = "Asia/Singapore";
        }
        switch ($format) {
            case 1:
                $TimeFormat = "d M y";
                break;

            case 2:
                $TimeFormat = "d M y h:i:s A";
                break;

            case 3:
                $TimeFormat = "Y-m-d H:i:s";
                break;

            case 4:
                $TimeFormat = "d M Y, H:i:s A";
                break;

            case 5:
                $TimeFormat = "d M Y, H:i:s A";
                break;

            case 6:
                $TimeFormat = "d M y, H:i A";
                break;
        }
        //echo GetLocalToServerOffset($Timezone)."<br/>";
        $DateTimeValue = strtotime($DateValue) + GetLocalToServerOffset($Timezone);
        $OffsetDateTime = date($TimeFormat, $DateTimeValue);
        return $OffsetDateTime;
    }

    public function GetLocalToServerOffset($Timezone) {
        /**
          $Timezone = User Session TimeZone

          returns server offset
         */
        if ($Timezone == "") {
            $Timezone = "Asia/Singapore";
        }
        
        $LocalTimeZone = new DateTimeZone("$Timezone");
        $ServerTimeZone = new DateTimeZone(date_default_timezone_get()); //server time set

        $LocalCurrentTime = new DateTime("now", $LocalTimeZone);
        $ServerCurrentTime = new DateTime("now", $ServerTimeZone);
        $offset = $ServerTimeZone->getOffset($ServerCurrentTime) - $LocalTimeZone->getOffset($LocalCurrentTime);
        return $offset;
    }

}

?>
