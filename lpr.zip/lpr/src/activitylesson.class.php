<?php
/**
 * Description of lessonactivity
 *
 * @author Tim
 */
require_once(__DIR__.'/activity.class.php');
require_once(__DIR__.'/syllabusutility.class.php');

class ActivityLesson extends Activity {
    private $_items;
    private $_items2;
    private $_entitytable;
    private $_tracetable;
    private $_syllabusutility;
    
    
    
    public function __construct() {
        parent::__construct();
        $this->_items = array();
        $this->_items2 = array();
        $this->_entitytable = 'TBL_SyllabusVideos';
        $this->_tracetable = 'QRY_'.$_SESSION['SessionSchoolID'].'_UsageVL';
        $this->_syllabusutility = new SyllabusUtility($this->_dbmanager);
    }
    
    /*
     * Override functions defined in parent class
     */
    public function read(array $activity) {
        parent::read($activity);
        $this->_read();
        $this->_updateLock();
    }
    
    public function listHtml($index) {
        return $this->_listHtml($index);
    }
    
    public function isStarted(array $lpassignidarr) {
        $lpassignids = implode(',', $lpassignidarr);
        $sql = "select count(*) from ".$this->_tracetable." VL where VL.LPAssignID in (".$lpassignids.")";
        $result = $this->_dbmanager->execute($sql);
        if(!$result){
            return -1;
        }
        $row = $this->_dbmanager->fetch_array($result);
        return $row[0] > 0 ? 1 : 0;
    }
    
    /*
     * internal functions
     */
    protected function _updateLock() {
        $fh = fopen("lp-lesson.txt", 'a+');
        if($fh){
                fwrite($fh, var_export($this->_items, true)."\r\n\r\n");
        }
        fclose($fh);
        
        foreach($this->_items as $item){
            if($item['finish'] == 0){
                $this->_lock = 1;
                return ;
            }
        }
        $this->_lock = 0;
    }
    
    private function _read(){
        $contentIdStr = '';
        $contentIdArr = explode(',', $this->_contentid);
        $contentIdAss = array();
        foreach($contentIdArr as $lessonItem){
            $lessonItemDetails = explode('|', $lessonItem);
            $contentIdStr .= "'".trim($lessonItemDetails[0])."',";
            $contentIdAss[$lessonItemDetails[0]] = array('data'=>$lessonItem, 'subtopic'=>$this->_syllabusutility->getTopicById($lessonItemDetails[6], $lessonItemDetails[2], $lessonItemDetails[3], $lessonItemDetails[4], $lessonItemDetails[5])['subtopicname']);
        }
        $contentIds = substr($contentIdStr, 0, -1);
        
        $sql_def = "select SV.ID, SV.Title, SV.URL from ".$this->_entitytable." SV where ID in (".$contentIds.") order by field(ID,".$contentIds.")";

        $fh = fopen("lp-lesson.txt", 'a+');
        if($fh){
                fwrite($fh, "activitylesson.class.php\r\n");
                fwrite($fh, $sql_def);
        }
        fclose($fh);
        
        $result_def = $this->_dbmanager->execute($sql_def);
        if($result_def){
            while($row_def = $this->_dbmanager->fetch_array($result_def)){
                $item = array('lpid' => $this->_lpid, 'id' => $row_def['ID'], 'title' => $row_def['Title'], 'url' => $row_def['URL'], 'finish' => 0, 'date' => '');
                $sql_trace = "select count(*) as Finish, max(StartDate) as StartDate from ".$this->_tracetable." UVL where LPActivityID = ".$this->_id." and LPAssignID = ".$this->_lpassignid." and UserID = ".$this->_studentid." and ID = '".$row_def['ID']."'";
                $result_trace = $this->_dbmanager->execute($sql_trace);
                if($result_trace){
                    $row_trace = $this->_dbmanager->fetch_array($result_trace);
                    $item['finish'] = $row_trace['Finish'];
                    $item['date'] = $row_trace['StartDate'];
                }
                $this->_items[] = $item;
                //construct subtopic association array
                $item['data'] = $contentIdAss[$item['id']]['data'];
                if(!isset($this->_items2[$contentIdAss[$item['id']]['subtopic']])){
                    $this->_items2[$contentIdAss[$item['id']]['subtopic']] = array();
                }
                $this->_items2[$contentIdAss[$item['id']]['subtopic']][] = $item;
            }
        }
    }
    
    private function _listHtml($index){
        
        $fh = fopen("lp-lesson.txt", 'a+');
        if($fh){
                fwrite($fh, "activitylesson.class.php[_listHtml]\r\n");
                fwrite($fh, var_export($this->_items2, true));
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $html = '';
        // construct html code of current activity
        switch($this->_mode){
            case 1:
                $html .= '<div class="package-content-holder pc-drop-shadow">
                            <div class="activity-gist">
                                <div class="left gist-icon" data="165">
                                    <img src="/w/img/icons/timeline-lessons.png">
                                </div>
                                <div class="gist-content" data="165">
                                    <table><tbody><tr><td>'.$this->_title.'</td></tr></tbody></table>
                                </div>
                            </div>
                            <div style="display: block;" class="activity-details">
                                <div class="activity-details-wrapper">
                                    <div class="instruction-text">
                                        <p>'.$this->_description.'</p>
                                    </div>
                                    <div class="activity-content">';
                foreach($this->_items2 as $subtopic => $items){
                    $html .= '              <div class="table-container">
                                                <div class="icon-bullet">
                                                    <span>&#8226;</span>
                                                </div>
                                                <div class="lesson-primary-column">
                                                    '.$subtopic.'
                                                </div>
                                            </div>		
                                            <div class="lesson-content">';
                    foreach($items as $item){
                        $paramDetails = explode('|', $item['data']);
                        $paramStr = '/w/courses2/DisplayT.php?TypeID=Videos&ID='.$paramDetails[0].'&SyllabusID='.$paramDetails[2].'&SectionID='.$paramDetails[3].'&TopicID='.$paramDetails[4].'&SubTopicID='.$paramDetails[5];
                        switch($paramDetails[1]){
                            case 1:
                                $paramStr .= '&Voice=SG&Sound=0';
                                break;
                            case 2:
                                $paramStr .= '&Voice=US&Sound=0';
                                break;
                        }
                        $html .= '              <div class="lesson-table-container">
                                                    <div class="lesson-icon-bullet">
                                                        <span>&#9657;</span>
                                                    </div>
                                                    <div class="lesson-primary-column">
                                                        <a class="ace-button btn-link" href="javascript:openWindowFS(\''.$paramStr.'\', \''.$paramDetails[0].'\');">'.$item['title'].'</a>
                                                    </div>
                                                </div>';   
                    }
                    $html .= '              </div>';
                }                                                
                $html .= '          </div>    
                                </div>
                            </div>    
                            <div class="package-content-lock" style="display:none;"></div>
                         </div>';
                break;
            case 2:
                $html .= '<div class="package-content-holder pc-drop-shadow">
                            <div class="activity-gist">
                                <div class="left gist-icon" data="165">
                                    <img src="/w/img/icons/timeline-lessons.png">
                                </div>
                                <div class="gist-content" data="165">
                                    <table><tbody><tr><td>'.$this->_title.'</td></tr></tbody></table>
                                </div>
                            </div>
                            <div style="display: block;" class="activity-details">
                                <div class="activity-details-wrapper">
                                    <div class="instruction-text">
                                        <p>'.$this->_description.'</p>
                                    </div>
                                    <div class="activity-content">';
                foreach($this->_items2 as $subtopic => $items){
                    $html .=            '<div class="table-container">
                                            <div class="icon-bullet">
                                                <span>&#8226;</span>
                                            </div>
                                            <div class="lesson-primary-column">
                                                '.$subtopic.'
                                            </div>
                                        </div>		
                                        <div class="lesson-content">';
                    foreach($items as $item){
                        $views = $item['finish'] == 0 ? '' : ($item['finish'] == 1 ? $item['finish'].' view' : $item['finish'].' views');
                        $date = empty($item['date']) ? '' : 'last view: '.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $item['date'], 6);
                        $html .=            '<div class="lesson-table-container">
                                                <div class="lesson-icon-bullet">
                                                    <span>&#9657;</span>
                                                </div>
                                                <div class="lesson-primary-column">
                                                    <a class="ace-button btn-link " data="'.$this->_typeid.'-'.$this->_id.'-'.$item['id'].'-'.$this->_lpassignid.'" href="javascript:void(0);">'.$indexprefix.$item['title'].'</a>
                                                </div>
                                                <div class="record-view">
                                                    '.$views.'
                                                </div>
                                                <div class="record-date">
                                                    '.$date.'
                                                </div>
                                            </div>';
                    }
                    $html .=           '</div>';
                }   
                $html .=            '</div>    
                                </div>
                            </div>

                            <div class="package-content-lock" style="display: none;"></div>
                        </div>';
                break;
        }
        return $html;
    }
    
    
}

?>