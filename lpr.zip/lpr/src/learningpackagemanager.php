<?php
/**
 *
 * @author Tim
 */
interface ILearningPackageManager {
    public function create(array $learningpackageentity_assignmententity, $mode);   // $mode: 1, learningpackage; 2, assignment; 3, learningpackage and assignment
    public function read($learningpackageid_assignmentid, $mode);     // $mode: 1, learningpackage; 2, assignment
    public function update(array $learningpackageentity_assignmententity, $mode);     //$mode: 1, learningpackage; 2, assignment
    public function delete($learningpackageid_assignmentid, $mode);     // $mode: 1, learningpackage; 2, assignment
}

?>