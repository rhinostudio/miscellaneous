<?php

/**
 * Description of activity
 *
 * @author Tim
 */
require_once(__DIR__.'/dbmanager.class.php');
require_once(__DIR__.'/activity.class.php');

class ActivityManager {
    private $_activityTypes;
    private $_activities;
    
    public function __construct(){
        $this->_activityTypes = array('Reserved', 'Topic', 'Lesson', 'InteractiveTools', 'Link', 'Document', 'Quiz', 'SkillMastery', 'PracticeDrills');
        $this->_activities = array();
    }
    
    /*
     * public functions which can be called outside
     */
    public function create(array $learningpackageentity_assignmententity, $mode) {
        ;
    }
    
    public function read(array $activities) {
        $this->_read($activities);
    }
    
    public function update(array $learningpackageentity_assignmententity, $mode) {
        ;
    }
    
    public function delete($learningpackageid_assignmentid, $mode) {
        ;
    }
    
    public function getActivities(){
        return $this->_activities;
    }
    
    public function listHtml(){
        return $this->_listHtml();
    }
    
    public function isStarted(array $lpassignidarr){
        $isStarted = 0;
        foreach($this->_activities as $activity){
            $isStarted |= $activity->isStarted($lpassignidarr);
        }
        return $isStarted;
    }
    
    
    /*
     * internal functions
     */
    private function _read(array $activities){
        $activityClassName = '';
        $activityFileName = '';
        foreach($activities as $activity){
            $activityClassName = 'activity'.strtolower($this->_activityTypes[$activity['typeid']]);
            $activityFileName = $activityClassName.'.class.php';
            $fh = fopen("lp-activitymanager.txt", 'a+');
            if($fh){
                    fwrite($fh, $activityFileName."\r\n\r\n");
            }
            require_once(__DIR__.'/'.$activityFileName);
            fwrite($fh, $activityFileName."  required..\r\n\r\n");
            $activityEntity = new $activityClassName();
            fwrite($fh, $activityFileName."  created..\r\n\r\n");
            fclose($fh);
            $activityEntity->read($activity);
            $this->_activities[] = $activityEntity;
        }
    }
    
    private function _listHtml(){
        $html = '';
        $index = 1;
        foreach($this->_activities as $activity){
            $html .= $activity->listHtml($index++);
        }
        return $html;
    }
    
}
?>