<?php

/**
 * Description of itemmanager
 *
 * @author Tim
 */
require_once(__DIR__ . '/dbmanager.class.php');

class ItemManager {
    private $_itemTypes;

    public function __construct() {
        $this->_itemTypes = array('Reserved', 'Topic', 'Lesson', 'InteractiveTools', 'Link', 'Document', 'Quiz', 'SkillMastery', 'PracticeDrills');
    }

    /*
     * public functions which can be called outside
     */
    public function updateViews($paramjsonstr) {
        $paramArr = $this->_getParamArray($paramjsonstr);
        $typeId = $paramArr['typeid'];
        $activityId = $paramArr['activityid'];
        $id = $paramArr['id'];
        $lpassignid = $paramArr['lpassignid'];
        if (!isset($typeId) || !isset($activityId) || !isset($id) || !isset($lpassignid)) {
            echo 1;
            exit(1);
        }
        echo $typeId . '^' . $activityId . '^' . $id . '^' . $lpassignid . '^' . $this->_updateViews($typeId, $activityId, $id, $lpassignid);
    }
    
    public function listHtml($paramjsonstr){
        $paramArr = $this->_getParamArray($paramjsonstr);
        $typeId = $paramArr['typeid'];
        $activityId = $paramArr['activityid'];
        $id = $paramArr['id'];
        $lpassignid = $paramArr['lpassignid'];
        if (!isset($typeId) || !isset($activityId) || !isset($id) || !isset($lpassignid)) {
            echo 1;
            exit(1);
        }
        echo $this->_listHtml($typeId, $activityId, $id, $lpassignid);
    }

    /*
     * internal functions
     */

    private function _updateViews($typeid, $activityid, $id, $lpassignid) {
        $itemClassName = 'item' . strtolower($this->_itemTypes[$typeid]);
        $itemFileName = $itemClassName . '.class.php';
        require_once(__DIR__ . '/' . $itemFileName);
        $itemEntity = new $itemClassName();
        $retValue = $itemEntity->updateViews($activityid, $id, $lpassignid);
        return $retValue;
    }

    private function _listHtml($typeid, $activityid, $id, $lpassignid){
        $itemClassName = 'item' . strtolower($this->_itemTypes[$typeid]);
        $itemFileName = $itemClassName . '.class.php';
        
        
        $fh = fopen("item-manager.txt", 'a+');
        if($fh){
                fwrite($fh, $itemFileName."\r\n\r\n");
        }
        
        require_once(__DIR__ . '/' . $itemFileName);
        
        if($fh){
                fwrite($fh, "require_once ".__DIR__ . '/' . $itemFileName."\r\n\r\n");
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $itemEntity = new $itemClassName();
        return $itemEntity->listHtml($activityid, $id, $lpassignid);
    }
    
    private function _getParamArray($jsonstr) {
        $pobj = json_decode($jsonstr);
        if ($pobj == NULL) {
            return $this->_string2array($jsonstr);
        } else {
            return $this->_object2array($pobj);
        }
    }

    private function _string2array($pstr) {
        $spos = strpos($pstr, '{');
        $epos = strpos($pstr, '}');
        $str = substr($pstr, $spos + 1, $epos - $spos - 1);
        $rearr = array();
        $paramarr = explode(',', $str);
        foreach ($paramarr as $param) {
            $itemarr = explode(':', $param);
            $rearr[$this->_getorignalstring($itemarr[0])] = $this->_getorignalstring($itemarr[1]);
        }
        return $rearr;
    }

    private function _getorignalstring($pstr) {
        $match = array();
        $res = preg_match('/(\w+)/', $pstr, $match);
        return $res != 0 ? $match[1] : '';
    }

    private function _object2array(&$obj) {
        if (is_object($obj)) {
            $obj = get_object_vars($obj);
        }
        if (is_array($obj)) {
            return $obj;
        } else {
            return false;
        }
    }

}

?>