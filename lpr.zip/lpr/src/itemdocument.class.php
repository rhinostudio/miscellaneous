<?php

/**
 * Description of itemlesson
 *
 * @author Tim
 */
require_once(__DIR__.'/item.class.php');

class ItemDocument extends Item {
    private $_entityTable;
    private $_assignmentTable;
    private $_traceTable;
    
    public function __construct() {
        parent::__construct();
        $this->_entityTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_Resources';
        $this->_assignmentTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_ResourcesAssignment';
        $this->_traceTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_UsageFR';
    }
    
    /*
     * Override functions
     */
    public function updateViews($activityid, $id, $lpassignid) {
        $retValue = 0;
        $filename = '';
        $creatorid = 0;
        $courseid = '';
        $syllabusid = 0;
        $sectionid = 0;
        $topicid = 0;
        $subtopicid = 0;
        $assignid = 0;
        $sql_doc = "select R.FileName, R.UserID, R.CourseID, R.SyllabusID, R.SectionID, R.TopicID, R.SubTopicID, RA.AssignID from ".$this->_entityTable." R, ".$this->_assignmentTable." RA where RA.ID = R.ID and RA.LPAssignID = ".$lpassignid." and RA.LPActivityID = ".$activityid." and RA.ID = ".$id."";
        
        $fh = fopen("item-document.txt", 'a+');
        if($fh){
                fwrite($fh, "itemdocument.class.php\r\n");
                fwrite($fh, $sql_doc."\r\n\r\n");
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $result_doc = $this->_dbmanager->execute($sql_doc);
        if($result_doc && $this->_dbmanager->num_rows($result_doc) > 0){
            $row_doc = $this->_dbmanager->fetch_array($result_doc);
            $filename = $row_doc['FileName'];
            $creatorid = $row_doc['UserID'];
            $courseid = $row_doc['CourseID'];
            $syllabusid = $row_doc['SyllabusID'];
            $sectionid = $row_doc['SectionID'];
            $topicid = $row_doc['TopicID'];
            $subtopicid = $row_doc['SubTopicID'];
            $assignid = $row_doc['AssignID'];
        }
        
        $sql = "insert into ".$this->_traceTable."(UserID, UserTypeID, CourseID, SyllabusID, SectionID, TopicID, SubTopicID, ID, StartDate, IPAddress, AssignID) values (".$_SESSION['SessionUserID'].", ".$_SESSION['SessionUserTypeID'].", '"
                .$courseid."', '".$syllabusid."', '".$sectionid."', '".$topicid."', '".$subtopicid."', '".$id."', now(), '".$_SERVER['HTTP_PC_REMOTE_ADDR']."', ".$assignid.")";
        
        $fh = fopen("item-document.txt", 'a+');
        if($fh){
                fwrite($fh, "itemdocument.class.php\r\n");
                fwrite($fh, $sql."\r\n\r\n");
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $this->_dbmanager->execute($sql);
        if($this->_dbmanager->affected_rows() > 0){
            $retValue = '0^'.$filename.'|'.$creatorid;
        }else{
            $retValue = 1;
        }
        return $retValue;
    }
    
}

?>