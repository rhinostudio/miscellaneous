<?php
/**
 * Description of learningpackagemanager
 *
 * @author Tim
 */
require_once(__DIR__.'/dbmanager.class.php');
require_once(__DIR__.'/learningpackagemanager.php');
require_once(__DIR__.'/learningpackage.class.php');
require_once(__DIR__.'/activitymanager.class.php');

class LearningPackageManager implements ILearningPackageManager{
    private $_learningpackage;
    private $_activitymanager;
    private $_mode; // 0:default; 1:learning-package; 2:assignment
    private $_studentid;
    
    public function __construct() {
        $this->_learningpackage = new LearningPackage();
        $this->_activitymanager = new ActivityManager();
        $this->_mode = 0;
        $this->_studentid = $_SESSION['SessionUserID'];
    }
    
    /*
     * public functions which can be called outside
     */
    public function listHtml($paramjsonstr) {
        $paramArr = $this->_getParamArray($paramjsonstr);
        $learningpackageid_assignmentid = $paramArr['assignid'];
        $mode = $paramArr['mode'];
        $studentId = $paramArr['studentid'];
        if(!isset($learningpackageid_assignmentid) || !isset($mode)){
            echo '[error]parameters past to controller.';
            exit(1);
        }
        if(isset($studentId)){
            $this->_studentid = $studentId;
            $this->_learningpackage->setStudentId($studentId);
        }
        $this->read($learningpackageid_assignmentid, $mode);  // $mode: 1, learningpackage; 2, assignment
        echo $this->_listHtml();
    }
    
    public function create(array $learningpackageentity_assignmententity, $mode) {
        ;
    }
    
    public function read($learningpackageid_assignmentid, $mode) {  // $mode: 1, learningpackage; 2, assignment
        $this->_mode = $mode;
        $this->_learningpackage->read($learningpackageid_assignmentid, $mode);
        $this->_activitymanager->read($this->_learningpackage->getActitivies());
        if($mode == 2 && $this->_learningpackage->getLock() == 1){
            $this->_updateLearningPackageActivitiesLocks();
        }
    }
    
    public function update(array $learningpackageentity_assignmententity, $mode) {
        ;
    }
    
    public function delete($learningpackageid_assignmentid, $mode) {
        ;
    }
    
    public function isStarted(array $lpassignidarr){
        $this->read($lpassignidarr[0], 2);
        return $this->_activitymanager->isStarted($lpassignidarr);
    }
    
    
    
    /*
     * internal functions
     */
    private function _updateLearningPackageActivitiesLocks(){
        $lpactivities = $this->_learningpackage->getActitivies();
        $activities = $this->_activitymanager->getActivities();
        $this->_updateLearningPackageActivitiesLockByIndex(0, 0);
        for($i = 1; $i < count($lpactivities); $i++){
            $this->_updateLearningPackageActivitiesLockByIndex($i, $activities[$i - 1]->isLock());
        }
    }
    
    private function _updateLearningPackageActivitiesLockByIndex($index, $lock){
        $this->_learningpackage->setActivitiesLock($index, $lock);
    }
    
    private function _listHtml(){
        // lists learningpackage page's html code
        $html = '';
        switch($this->_mode){
            case 1:
                $html .= $this->_learningpackage->listHtml();
                $html .= '<div id="output-holder">';
                $html .= $this->_activitymanager->listHtml();
                $html .= '</div></div></div>';
                break;
            case 2:
                $html .= $this->_learningpackage->listHtml();
                $html .=   '<div class="clearfix"></div>
                            <div id="content-holder" class="row">
                                <div class="col-md-12">
                                    <div id="output-holder">';
                $html .= $this->_activitymanager->listHtml();
                $html .= '</div></div></div>';
                break;
            case 3:
                break;
        }
        return $html;
    }
    
    private function _getParamArray($jsonstr) {
        $pobj = json_decode($jsonstr);
        if ($pobj == NULL) {
            return $this->_string2array($jsonstr);
        } else {
            return $this->_object2array($pobj);
        }
    }

    private function _string2array($pstr) {
        $spos = strpos($pstr, '{');
        $epos = strpos($pstr, '}');
        $str = substr($pstr, $spos + 1, $epos - $spos - 1);
        $rearr = array();
        $paramarr = explode(',', $str);
        foreach ($paramarr as $param) {
            $itemarr = explode(':', $param);
            $rearr[$this->_getorignalstring($itemarr[0])] = $this->_getorignalstring($itemarr[1]);
        }
        return $rearr;
    }

    private function _getorignalstring($pstr) {
        $match = array();
        $res = preg_match('/(\w+)/', $pstr, $match);
        return $res != 0 ? $match[1] : '';
    }

    private function _object2array(&$obj) {
        if (is_object($obj)) {
            $obj = get_object_vars($obj);
        }
        if (is_array($obj)) {
            return $obj;
        } else {
            return false;
        }
    }
    
}
?>