<?php

/**
 * Description of itemlesson
 *
 * @author Tim
 */
require_once(__DIR__.'/item.class.php');

class ItemQuiz extends Item {
    private $_assignmentTable;
    
    public function __construct() {
        parent::__construct();
        $this->_assignmentTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_QuizAssignment';
    }
    
    /*
     * Override functions
     */
    public function addAssignment4LearningPackage(array $settings){
        return $this->_addAssignment4LearningPackage($settings);
    }
    
    
    /*
     * Internal functions
     */
    private function _addAssignment4LearningPackage(array $settings){
        $retValue = '';
        
        return $retValue;
    }
    
}

?>
