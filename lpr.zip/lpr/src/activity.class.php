<?php

/**
 * Description of activity
 *
 * @author Tim
 */
require_once(__DIR__.'/dbmanager.class.php');
require_once(__DIR__.'/timemanager.class.php');

abstract class Activity {
    protected $_dbmanager;
    protected $_timemanager;
    protected $_errno;
    protected $_lock;
    protected $_lpassignid;
    protected $_lpid;
    protected $_id;
    protected $_typeid;
    protected $_title;
    protected $_description;
    protected $_contentid;
    protected $_mode; // 0:default; 1:view-read; 2:assignment
    protected $_studentid;
    
    public function __construct() {
        $this->_dbmanager = DbManager::getInstance();
        if(!$this->_dbmanager->connect2Db()){
            $this->_errno = 1;
            return ;
        }
        $this->_timemanager = new TimeManager();
        $this->_lpassignid = 0;
        $this->_lpid = 0;
        $this->_id = 0;
        $this->_typeid = 0;
        $this->_title = '';
        $this->_description = '';
        $this->_contentid = '';
        $this->_lock = 0;
        $this->_mode = 0;
        $this->_studentid = $_SESSION['SessionUserID'];
    }
    
    
    /*
     * public functions which can be called outside
     */
    public function read(array $activity){
        $this->_lpassignid = $activity['lpasignid'];
        $this->_lpid = $activity['lpid'];
        $this->_id = $activity['id'];
        $this->_typeid = $activity['typeid'];
        $this->_title = $activity['title'];
        $this->_description = $activity['description'];
        $this->_contentid = $activity['contentid'];
        $this->_lock = $activity['lock'];
        $this->_mode = $activity['mode'];
        $this->_studentid = $activity['studentid'];
    }
    
    public function isLock() {
        return $this->_lock;
    }
    
    abstract public function listHtml($index);
    abstract public function isStarted(array $lpassignidarr);


    /*
     * internal functions
     */
    abstract protected function _updateLock();
    protected function _dateFormat($mysql_datetime){
        $dateTime = array();
        if(empty($mysql_datetime) || $mysql_datetime === '0000-00-00 00:00:00'){
            return '-';
        }
        if(preg_match('/(\d+)-(\d+)-(\d+)\s+(\d+):(\d+):(\d+)/', $mysql_datetime, $dateTime) === 1){
            return date('d M y, h:i A', mktime($dateTime[4], $dateTime[5], $dateTime[6], $dateTime[2], $dateTime[3], $dateTime[1]));
        }else{
            return 'format-error';
        }
    }
    // encrypt assignid for quiz, worksheet, journal
    protected function _encodeAssignid($assignid, $activitytype){   //$activitytype: defined and used in /w/assignments/view.php
        $random = substr(time()* (600*60*60), 0, 6);
        $random2 = substr(time() * (300*60*60), 0, 6);
        return $random.'0'.$random2.$assignid."_".$activitytype;
    }
}

?>