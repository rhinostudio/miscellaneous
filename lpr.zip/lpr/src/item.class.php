<?php

/**
 * Description of item
 *
 * @author Tim
 */
require_once(__DIR__.'/dbmanager.class.php');

abstract class Item {
    protected $_dbmanager;
    protected $_errno;
    protected $_activityid;
    protected $_activitytitle;
    protected $_id;
    protected $_title;
    
    public function __construct() {
        $this->_dbmanager = DbManager::getInstance();
        if(!$this->_dbmanager->connect2Db()){
            $this->_errno = 1;
            return ;
        }
        $this->_activityid = 0;
        $this->_activitytitle = '';
        $this->_id = 0;
        $this->_title = '';
    }
    
}

?>