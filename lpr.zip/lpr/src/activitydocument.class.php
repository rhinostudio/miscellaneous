<?php
/**
 * Description of linkactivity
 *
 * @author Tim
 */
require_once(__DIR__.'/activity.class.php');

class ActivityDocument extends Activity {
    private $_items;
    private $_entitytable;
    private $_assigntable;
    private $_tracetable;
    private $_facultyprofile;
    
    
    
    public function __construct() {
        parent::__construct();
        $this->_items = array();
        $this->_entitytable = 'QRY_'.$_SESSION['SessionSchoolID'].'_Resources';
        $this->_assigntable = 'QRY_'.$_SESSION['SessionSchoolID'].'_ResourcesAssignment';
        $this->_tracetable = 'QRY_'.$_SESSION['SessionSchoolID'].'_UsageFR';
        $this->_facultyprofile = 'TBL_FacultyProfile';
        $fh = fopen("lp-document.txt", 'a+');
        if($fh){
                fwrite($fh, "__construct()\r\n\r\n");
        }
        fclose($fh);
    }
    
    /*
     * Override functions defined in parent class
     */
    public function read(array $activity) {
        parent::read($activity);
        $this->_read();
        $this->_updateLock();
    }
    
    public function listHtml($index) {
        return $this->_listHtml($index);
    }
    
    public function isStarted(array $lpassignidarr) {
        $lpassignids = implode(',', $lpassignidarr);
        $sql = "select count(*) from ".$this->_tracetable." UR, ".$this->_assigntable." RA where UR.AssignID = RA.AssignID and RA.LPAssignID in (".$lpassignids.")";
        $result = $this->_dbmanager->execute($sql);
        if(!$result){
            return -1;
        }
        $row = $this->_dbmanager->fetch_array($result);
        return $row[0] > 0 ? 1 : 0;
    }
    
    /*
     * internal functions
     */
    protected function _updateLock() {
        $fh = fopen("lp-document.txt", 'a+');
        if($fh){
                fwrite($fh, var_export($this->_items, true)."\r\n\r\n");
        }
        fclose($fh);
        
        foreach($this->_items as $item){
            if($item['finish'] == 0){
                $this->_lock = 1;
                return ;
            }
        }
        $this->_lock = 0;
    }
    
    private function _read(){
        if($this->_mode == 1){
            $sql_def = "select R.ID, R.Title, R.FileName, R.OriginalName, R.UserID, FP.SchoolID from ".$this->_entitytable." R, ".$this->_facultyprofile." FP where R.UserID = FP.UserID and R.ID in (".$this->_contentid.") order by field(R.ID,".$this->_contentid.")";
        }elseif($this->_mode == 2){
            $sql_def = "select R.ID, R.Title, R.FileName, R.OriginalName, RA.AssignID, R.UserID, FP.SchoolID from ".$this->_entitytable." R, ".$this->_assigntable." RA, ".$this->_facultyprofile." FP where RA.LPAssignID = ".$this->_lpassignid." and RA.LPActivityID = ".$this->_id." and RA.ID = R.ID and R.UserID = FP.UserID order by field(R.ID,".$this->_contentid.")";
        }
        
        $fh = fopen("lp-document.txt", 'a+');
        if($fh){
                fwrite($fh, "activitydocument.class.php\r\n");
                fwrite($fh, $sql_def);
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $result_def = $this->_dbmanager->execute($sql_def);
        if($result_def){
            while($row_def = $this->_dbmanager->fetch_array($result_def)){
                $item = array('lpid' => $this->_lpid, 'id' => $row_def['ID'], 'title' => $row_def['Title'], 'filename' => $row_def['FileName'], 'originalname' => $row_def['OriginalName'], 'assignid' => ($row_def['AssignID'] ? $row_def['AssignID'] : 0), 'userid' => $row_def['UserID'], 'schoolid' => $row_def['SchoolID'], 'finish' => 0, 'date' => '');
                $sql_trace = "select count(*) as Finish, max(StartDate) as StartDate from ".$this->_tracetable." UFR where AssignID = ".$row_def['AssignID']." and UserID = ".$this->_studentid." and ID = ".$row_def['ID'];
                
                $fh = fopen("lp-document.txt", 'a+');
                if($fh){
                        fwrite($fh, $sql_trace);
                        fwrite($fh, "\r\n\r\n\r\n");
                }
                fclose($fh);
                
                $result_trace = $this->_dbmanager->execute($sql_trace);
                if($result_trace){
                    $row_trace = $this->_dbmanager->fetch_array($result_trace);
                    $item['finish'] = $row_trace['Finish'];
                    $item['date'] = $row_trace['StartDate'];
                }
                $this->_items[] = $item;
            }
        }
    }
    
    private function _listHtml($index){
        $html = '';
        // construct html code of current activity
        switch($this->_mode){
            case 1:
                $html .= '<div class="package-content-holder pc-drop-shadow">
                            <div class="activity-gist">
                                <div class="left gist-icon" data="165">
                                    <img src="/w/img/icons/timeline-document.png">
                                </div>
                                <div class="gist-content" data="165">
                                    <table><tbody><tr><td>'.$this->_title.'</td></tr></tbody></table>
                                </div>
                            </div>
                            <div style="display: block;" class="activity-details">
                                <div class="activity-details-wrapper">
                                    <div class="instruction-text">
                                        <p>'.$this->_description.'</p>
                                    </div>
                                    <div class="activity-content">';
                foreach($this->_items as $item){
                    $html .= '              <div class="table-container">
                                                <div class="icon-bullet">
                                                    <span>&#8226;</span>
                                                </div>
                                                <div class="primary-column">
                                                    <a class="ace-button btn-link" href="javascript:openWindowFS(\'/w/includes/file.php?type=file&amp;file='.$item['schoolid'].';'.$item['filename'].';'.$item['userid'].'\',\'DLWindow\')" title="Document">'.$item['title'].'</a>
                                                </div>
                                            </div>';
                }                                                
                $html .= '          </div>    
                                </div>
                            </div>    
                            <div class="package-content-lock" style="display:none;"></div>
                         </div>';
                break;
            case 2:
                $html .= '<div class="package-content-holder pc-drop-shadow">
                            <div class="activity-gist">
                                <div class="left gist-icon" data="165">
                                    <img src="/w/img/icons/timeline-document.png">
                                </div>
                                <div class="gist-content" data="165">
                                    <table><tbody><tr><td>'.$this->_title.'</td></tr></tbody></table>
                                </div>
                            </div>
                            <div style="display: block;" class="activity-details">
                                <div class="activity-details-wrapper">
                                    <div class="instruction-text">
                                        <p>'.$this->_description.'</p>
                                    </div>
                                    <div class="activity-content">';
                foreach($this->_items as $item){
                    $views = $item['finish'] == 0 ? '' : ($item['finish'] == 1 ? $item['finish'].' view' : $item['finish'].' views');
                    $date = empty($item['date']) ? '' : 'last view: '.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $item['date'], 6);
                    $html .=           '<div class="table-container">
                                            <div class="icon-bullet">
                                                <span>&#8226;</span>
                                            </div>
                                            <div class="primary-column">
                                                <a class="ace-button btn-link" data="'.$this->_typeid.'-'.$this->_id.'-'.$item['id'].'-'.$this->_lpassignid.'" href="javascript:void(0);">'.$item['title'].'</a>
                                            </div>
                                            <div class="record-view">
                                                '.$views.'
                                            </div>
                                            <div class="record-date">
                                                '.$date.'
                                            </div>
                                        </div>';
                }
                $html .=            '</div>    
                                </div>
                            </div>
                            <div class="package-content-lock" style="display:none;"></div>
                        </div>';
                break;
        }
        return $html;
    }
    
    
}

?>