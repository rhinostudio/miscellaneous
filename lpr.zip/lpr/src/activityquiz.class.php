<?php
/**
 * Description of lessonactivity
 *
 * @author Tim
 */
require_once(__DIR__.'/activity.class.php');

class ActivityQuiz extends Activity {
    private $_items;
    private $_entitytable;
    private $_assigntable;
    private $_tracetable;
    private $_tracetable2;
    
    
    
    public function __construct() {
        parent::__construct();
        $this->_items = array();
        $this->_entitytable = 'QRY_'.$_SESSION['SessionSchoolID'].'_Quiz';
        $this->_assigntable = 'QRY_'.$_SESSION['SessionSchoolID'].'_QuizAssignment';
        $this->_tracetable = 'QRY_'.$_SESSION['SessionSchoolID'].'_RecordTotal';
        $this->_tracetable2 = 'QRY_'.$_SESSION['SessionSchoolID'].'_RecordQns';
    }
    
    /*
     * Override functions defined in parent class
     */
    public function read(array $activity) {
        parent::read($activity);
        $this->_read();
        $this->_updateLock();
    }
    
    public function listHtml($index) {
        return $this->_listHtml($index);
    }
    
    public function isStarted(array $lpassignidarr) {
        $lpassignids = implode(',', $lpassignidarr);
        $sql = "select count(*) from ".$this->_tracetable2." RQ, ".$this->_assigntable." QA where RQ.AssignID = QA.AssignID and QA.LPAssignID in (".$lpassignids.")";
        $result = $this->_dbmanager->execute($sql);
        if(!$result){
            return -1;
        }
        $row = $this->_dbmanager->fetch_array($result);
        return $row[0] > 0 ? 1 : 0;
    }
    
    /*
     * internal functions
     */
    protected function _updateLock() {
        $fh = fopen("lp-quiz.txt", 'a+');
        if($fh){
                fwrite($fh, var_export($this->_items, true)."\r\n\r\n");
        }
        fclose($fh);
        foreach($this->_items as $item){
            if($item['finish'] == 0){
                $this->_lock = 1;
                return ;
            }
        }
        $this->_lock = 0;
    }
    
    private function _read(){
        $contentIdStr = '';
        $contentIdArr = explode(',', $this->_contentid);
        foreach($contentIdArr as $quizItem){
            $quizItemDetails = explode('|', $quizItem);
            $contentIdStr .= "'".trim($quizItemDetails[0])."',";
        }
        $contentIds = substr($contentIdStr, 0, -1);
        if($this->_mode == 1){
            $sql_def = "select Q.QuizID, Q.QuizName from ".$this->_entitytable." Q where Q.QuizID in (".$contentIds.") order by field(Q.QuizID,".$contentIds.")";
        }elseif($this->_mode == 2){
            $sql_def = "select Q.QuizID, Q.QuizName, QA.AssignID from ".$this->_entitytable." Q, ".$this->_assigntable." QA where QA.LPAssignID = ".$this->_lpassignid." and QA.LPActivityID = ".$this->_id." and QA.QuizID = Q.QuizID and Q.QuizID in (".$contentIds.") order by field(Q.QuizID,".$contentIds.")";
        }

        $fh = fopen("lp-quiz.txt", 'a+');
        if($fh){
                fwrite($fh, "activityquiz.class.php\r\n");
                fwrite($fh, $sql_def);
        }
        fclose($fh);
                
        $result_def = $this->_dbmanager->execute($sql_def);
        if($result_def){
            while($row_def = $this->_dbmanager->fetch_array($result_def)){
                $item = array('lpid' => $this->_lpid, 'id' => $row_def['QuizID'], 'title' => $row_def['QuizName'], 'assignid' => ($row_def['AssignID'] ? $row_def['AssignID'] : 0), 'score' => '', 'date' => '', 'finish' => 0);
                $sql_trace = "select Percentage, Date from ".$this->_tracetable." where AssignID = ".$row_def['AssignID']." and UserID = ".$this->_studentid." order by Percentage desc";
                $result_trace = $this->_dbmanager->execute($sql_trace);
                if($result_trace && $this->_dbmanager->num_rows($result_trace) > 0){
                    $row_trace = $this->_dbmanager->fetch_array($result_trace);
                    $item['score'] = $row_trace['Percentage'];
                    $item['date'] = $row_trace['Date'];
                    $item['finish'] = 1;
                }
                $this->_items[] = $item;
            }
        }
    }
    
    private function _listHtml($index){
        $html = '';
        // construct html code of current activity
        switch($this->_mode){
            case 1:
                $html .= '<div class="package-content-holder pc-drop-shadow">
                            <div class="activity-gist">
                                <div class="left gist-icon" data="165">
                                    <img src="/w/img/icons/timeline-quiz.png">
                                </div>
                                <div class="gist-content" data="165">
                                    <table><tbody><tr><td>'.$this->_title.'</td></tr></tbody></table>
                                </div>
                            </div>
                            <div style="display: block;" class="activity-details">
                                <div class="activity-details-wrapper">
                                    <div class="instruction-text">
                                        <p>'.$this->_description.'</p>
                                    </div>
                                    <div class="activity-content">';
                foreach($this->_items as $item){
                    $html .= '              <div class="table-container">
                                                <div class="icon-bullet">
                                                    <span>&#8226;</span>
                                                </div>
                                                <div class="primary-column">
                                                    <a class="ace-button btn-link" data="'.$item['id'].'" href="javascript:void(0);" title="Quiz">'.$item['title'].'</a>
                                                </div>
                                            </div>';
                }                                                
                $html .= '          </div>    
                                </div>
                            </div>    
                            <div class="package-content-lock" style="display:none;"></div>
                         </div>';
                break;
            case 2:
                $html .= '<div class="package-content-holder pc-drop-shadow">
                            <div class="activity-gist">
                                <div class="left gist-icon" data="165">
                                    <img src="/w/img/icons/timeline-link.png">
                                </div>
                                <div class="gist-content" data="165">
                                    <table><tbody><tr><td>'.$this->_title.'</td></tr></tbody></table>
                                </div>
                            </div>
                            <div style="display: block;" class="activity-details">
                                <div class="activity-details-wrapper">
                                    <div class="instruction-text">
                                        <p>'.$this->_description.'</p>
                                    </div>
                                    <div class="activity-content">';
                foreach($this->_items as $item){
                    $score = empty($item['score']) ? '' : $item['score'].' score';
                    $date = empty($item['date']) ? '' : 'last view: '.$this->_timemanager->ConvertToLocalTime($_SESSION['SessionTimeZone'], $item['date'], 6);
                    $html .=            '<div class="table-container">
                                            <div class="icon-bullet">
                                                <span>&#8226;</span>
                                            </div>
                                            <div class="primary-column">
                                                <a class="ace-button btn-link "  data="'.$this->_typeid.'-'.$this->_id.'-'.$item['id'].'-'.$this->_lpassignid.'-'.$this->_encodeAssignid($item['assignid'], 1).'" href="javascript:void(0);">'.$item['title'].'</a>
                                            </div>
                                            <div class="record-view">
                                                '.$score.'
                                            </div>
                                            <div class="record-date">
                                                '.$date.'
                                            </div>
                                        </div>';
                }    
                $html .=           '</div>    
                                </div>
                            </div>
                            <div class="package-content-lock" style="display: none;"></div>
                        </div>';          
                break;
        }
        return $html;
    }
    
    
}

?>