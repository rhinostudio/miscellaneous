<?php

/**
 * Description of itemlesson
 *
 * @author Tim
 */
require_once(__DIR__.'/item.class.php');

class ItemLesson extends Item {
    private $_previous;
    private $_next;
    private $_entityTable;
    private $_traceTable;
    private $_activityTable;
    private $_videoid;
    
    public function __construct() {
        parent::__construct();
        $this->_previous = '';
        $this->_next = '';
        $this->_entityTable = 'TBL_SyllabusVideos';
        $this->_traceTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_UsageVL';
        $this->_activityTable = 'QRY_'.$_SESSION['SessionSchoolID'].'_LearningPackage_Activities';
        $this->_videoid = 0;
    }
    
    /*
     * Override functions
     */
    public function updateViews($activityid, $id, $lpassignid) {
        $retValue = 0;
        $syllabusid = '';
        $sectionid = 0;
        $topicid = 0;
        $subtopicid = 0;
        $sql_video = "select SectionID, TopicID, SubTopicID from ".$this->_entityTable." where ID = '".$id."'";
        $result_video = $this->_dbmanager->execute($sql_video);
        if($result_video && $this->_dbmanager->num_rows($result_video) > 0){
            $row_video = $this->_dbmanager->fetch_array($result_video);
            $sectionid = $row_video['SectionID'];
            $topicid = $row_video['TopicID'];
            $subtopicid = $row_video['SubTopicID'];
        }
        $sql_activity = "select ContentID from ".$this->_activityTable." where LPActivityID = ".$activityid;
        $result_activity = $this->_dbmanager->execute($sql_activity);
        if($result_activity){
            $row_activity = $this->_dbmanager->fetch_array($result_activity);
            $pos = strpos($row_activity['ContentID'], $id);
            $syllabusid = substr($row_activity['ContentID'], $pos + 35, 5);
        }
        
        $sql = "insert into ".$this->_traceTable."(UserID, UserTypeID, SyllabusID, SectionID, TopicID, SubTopicID, ID, StartDate, LPActivityID, LPAssignID) values (".$_SESSION['SessionUserID'].", ".$_SESSION['SessionUserTypeID'].", '"
                .$syllabusid."', '".$sectionid."', '".$topicid."', '".$subtopicid."', '".$id."', now(), ".$activityid.', '.$lpassignid.")";
        $this->_dbmanager->execute($sql);
        if($this->_dbmanager->affected_rows() > 0){
            $retValue = 0;
        }else{
            $retValue = 1;
        }
        return $retValue;
    }
    
    public function listHtml($activityid, $id, $lpassignid){
        $this->_init($activityid, $id, $lpassignid);
        return $this->_listHtml();
    }
    
    
    /*
     * Internal functions
     */
    private function _init($activityid, $id, $lpassignid){
        $this->_activityid = $activityid;
        $this->_id = trim($id);
        $sql_activity = "select ActivityTypeID, Title, ContentID from QRY_".$_SESSION['SessionSchoolID']."_LearningPackage_Activities where LPActivityID = ".$this->_activityid;
        
        $fh = fopen("item-link.txt", 'a+');
        if($fh){
                fwrite($fh, "itemlesson.class.php\r\n");
                fwrite($fh, var_export($this, true)."\r\n\r\n");
                fwrite($fh, $sql_activity."\r\n\r\n");
                fwrite($fh, "\r\n\r\n\r\n");
        }
        fclose($fh);
        
        $result_activity = $this->_dbmanager->execute($sql_activity);
        if($result_activity){
            $row_activity = $this->_dbmanager->fetch_array($result_activity);
            $this->_activitytitle = $row_activity['Title'];
            $sibling = array();
            $contentArr = explode(',', $row_activity['ContentID']);
            $count = count($contentArr);
            for($i = 0; $i < $count; $i++){
                $itemDetail = explode('|', $contentArr[$i]);
                $sibling[] = $itemDetail[0];
            }
            for($i = 0; $i < $count; $i++){
                if($this->_id === trim($sibling[$i])){
                    if($i > 0){
                        $this->_previous = $row_activity['ActivityTypeID'].'-'.$this->_activityid.'-'.trim($sibling[$i - 1]).'-'.$lpassignid;
                    }
                    if($i < $count - 1){
                        $this->_next = $row_activity['ActivityTypeID'].'-'.$this->_activityid.'-'.trim($sibling[$i + 1]).'-'.$lpassignid;
                    }
                    if($i == $count - 1){
                        $this->_next = 0;
                    }
                }
            }
        }
        $sql_lesson = "select VideoID, Title from TBL_SyllabusVideos where ID = '".$this->_id."'";
        $result_lesson = $this->_dbmanager->execute($sql_lesson);
        if($result_lesson){
            $row_lesson = $this->_dbmanager->fetch_array($result_lesson);
            $this->_videoid = $row_lesson['VideoID'];
            $this->_title = $row_lesson['Title'];
        }
    }
    
    private function _listHtml(){
        $html = $this->_activitytitle.'|';
        if(!empty($this->_next)){
            $html .= '<div class="pull-right"><a class="ace-button btn-link" href="javascript:void(0);" data="'.$this->_next.'">Next</a></div>';
        }else if($this->_next === 0){
            $html .= '<div class="pull-right"><a class="ace-button btn-link" href="javascript:void(0);" data="'.$this->_next.'">Next Activity</a></div>';
        }
        if(!empty($this->_previous)){
            $html .= '<div><a class="ace-button btn-link" href="javascript:void(0);" data="'.$this->_previous.'">Previous</a></div>';
        }
        return $html;
    }
}

?>
