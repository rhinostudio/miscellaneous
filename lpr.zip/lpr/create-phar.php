<?php
    try{
        $phar = new Phar(__DIR__.'/lib/lpr.phar', CURRENT_AS_FILEINFO | FilesystemIterator::KEY_AS_FILENAME, 'lpr.phar');
    }catch(UnexpectedValueException $ueve){
        die('Could not open lpr.phar|error code: '.$ueve->getCode().'|error msg: '.$ueve->getMessage());
    }catch(BadMethodCallException $bmce){
        echo 'Technically, this cannot happen|error code: '.$bmce->getCode().'|error msg: '.$bmce->getMessage();
    }
    
    $phar->buildFromDirectory('./src');
    $phar->compressFiles(Phar::GZ);
?>
